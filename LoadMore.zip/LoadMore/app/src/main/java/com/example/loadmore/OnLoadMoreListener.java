package com.example.loadmore;

public interface OnLoadMoreListener {
    void onLoadMore();
}